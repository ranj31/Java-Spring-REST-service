package com.ranjan.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.ranjan.domain.Employee;
import com.ranjan.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping(value = "/employees", produces = "application/json")
	public ResponseEntity<List<Employee>> FindAll() {
		List<Employee> employeeList = employeeService.FindAll();
		if ((employeeList == null) || (employeeList.size() == 0)) {
			return new ResponseEntity("No Employee records found in database", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity(employeeList, HttpStatus.OK);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked", "unused" })
	@GetMapping(value = "/employees/{empId}", headers = "Accept=application/json")
	public ResponseEntity<Object> findEmployeeById(@PathVariable("empId") long empId) {
		System.out.println("findEmployeeById");
		Employee employee = employeeService.findEmployeeById(empId);
		if (employee == null) {
			return new ResponseEntity("No Employee found for Emp ID " + empId, HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity(employee, HttpStatus.OK);
	}
	
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@PostMapping(value = "/employees")
	public ResponseEntity createCustomer(@RequestBody Employee employee) {
		employeeService.createEmployee(employee);
		return new ResponseEntity(employee, HttpStatus.OK);
	}
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@DeleteMapping("/employees/{empId}")
	public ResponseEntity<Object> deleteEmployeeById(@PathVariable("empId") long empId) {
		System.out.println("deleteEmployeeById");
		if (null == employeeService.deleteEmployeeById(empId)) {
			return new ResponseEntity("No Employee found for Emp ID " + empId, HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity(empId, HttpStatus.OK);
	}
	

	@SuppressWarnings({ "rawtypes", "unchecked", "null" })
	@PutMapping("/employees")
	public ResponseEntity updateEmployee(@RequestBody Employee employee) {
		System.out.println("updateCustomer");
		employee = employeeService.updateEmployee(employee);
		if (null == employee) {
			return new ResponseEntity("No Employee found for ID " + employee.getEmpId(), HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity(employee, HttpStatus.OK);
	}
}