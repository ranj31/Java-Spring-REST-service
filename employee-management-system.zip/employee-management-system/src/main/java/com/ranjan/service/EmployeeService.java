package com.ranjan.service;

import java.util.List;

import com.ranjan.domain.Employee;

public interface EmployeeService {
	public List<Employee> FindAll();
	public Employee findEmployeeById(long empId);
	public Employee createEmployee(Employee employee);
	public Long deleteEmployeeById(long empId);
	public Employee updateEmployee(Employee employee);
}