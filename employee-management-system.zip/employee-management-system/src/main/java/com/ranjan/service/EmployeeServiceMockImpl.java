package com.ranjan.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.ranjan.domain.Employee;

@Repository
public class EmployeeServiceMockImpl implements EmployeeService {

	private List<Employee> employeesList = new ArrayList<Employee>();

	// populate the Employee List
	public EmployeeServiceMockImpl() {
		employeesList.add(new Employee(1, "Vijoy", "Programmer", 40000));
		employeesList.add(new Employee(2, "Moni", "Analyst", 50000));
		employeesList.add(new Employee(3, "Mukesh", "Administrator", 30000));
		employeesList.add(new Employee(4, "Rajen", "Designer", 40000));
		employeesList.add(new Employee(5, "Raksha", "Business", 50000));
		employeesList.add(new Employee(6, "Debolina", "Teacher", 10000));
	}
	
	/**
	 * Returns list of employees from dummy database List.
	 * 
	 * @return list of employees
	 */
	
	public List<Employee> FindAll() {
		if(employeesList.size() > 0) {
			return employeesList;
		}
		return null;
	}

	/**
	 * Return employee object for given id from dummy database. If employee is
	 * not found for id, returns null.
	 * 
	 * @param id   employee id
	 * @return employee object for given id
	 */
	
	public Employee findEmployeeById(long empId) {
		for (Employee employee : employeesList) {
			if (employee.getEmpId()== empId) {
				return employee;
			}
		}
		return null;
	}
	
	/**
	 * Create new Employee in dummy database List. Updates the id and insert new
	 * employee in list.
	 * 
	 * @param employee
	 *            Employee object
	 * @return employee object with updated id
	 */
	public Employee createEmployee(Employee employee) {
		employee.setEmpId(System.currentTimeMillis());
		employeesList.add(employee);
		return employee;
	}
	
	/**
	 * Delete the Employee object from dummy database List. If employee not found for
	 * given emp id, returns null.
	 * 
	 * @param id
	 *            the employee id
	 * @return id of deleted employee object
	 */
	
	public Long deleteEmployeeById(long empId) {
		int listid = 0;
		for (Employee employee : employeesList) {
			if (employee.getEmpId() == empId) {
				listid = employeesList.indexOf(employee);
				employeesList.remove(listid);
				return empId;
			}
		}
		return null;
	}
	
	/**
	 * Update the Employee object for given id in dummy database List. If employee
	 * not exists, returns null
	 * 
	 * @param id
	 * @param employee
	 * @return employee object with id
	 */
	public Employee updateEmployee(Employee employee) {
		int index = 0;
		for (Employee emp : employeesList) {
			if (emp.getEmpId() == employee.getEmpId()) {
				index = employeesList.indexOf(emp);
				employeesList.set(index, employee);
				return employee;
			}
		}
		return null;
	}
}